# Act 4: Shipment Verification & Pre-fill Skill

## 触发条件

**触发**：`Contract Application` 从 `Submitted` 变为 `Approved`
**来源**：Demo Script Act 4 / SOP Section 4.2

---

## 执行步骤

### Step 1: 读取记录（按 record_id）

从 Base 读取以下字段用于四件自查：

| 字段 | 用途 |
|------|------|
| ID | 记录标识 |
| Name of Entity | 发货表：Influencer |
| Model Name | 发货表：Product |
| Color | 发货表：Color |
| Size | 发货表：Size |
| Shipping Address | 四件自查① |
| Promised Live Date | 四件自查③ |
| POC | 四件自查④ / 通知人 |
| Manage by | 四件自查④ |
| Contract Amount (USD) | 预填参考 |
| Contract File Link | 发货通知附件 |

---

### Step 2: 四件自查（Daniel 2026-03-15 群聊）

```python
def verify_act4(record) -> dict:
    results = {}

    # ① 地址完整：street + city + state + ZIP
    addr = record.get("Shipping Address") or ""
    addr_parts = [p.strip() for p in addr.replace(",", " ").split() if p.strip()]
    # 简单判断：地址至少有 3 个词节（城市 + 州 + ZIP）
    results["address_complete"] = len(addr_parts) >= 3

    # ② 产品型号、颜色、尺码与合同一致（从 Base 读取，无对比基准时默认通过）
    model = record.get("Model Name")
    color = record.get("Color")
    size = record.get("Size")
    results["product_consistent"] = all([model, color, size])

    # ③ Promised Live Date 已填
    results["delivery_date_set"] = record.get("Promised Live Date") not in (None, "")

    # ④ POC 和 Manage by 已填
    poc = record.get("POC")
    managed = record.get("Manage by")
    results["poc_managed_set"] = bool(poc) and bool(managed)

    # 综合判断
    results["can_submit_shipment"] = all([
        results["address_complete"],
        results["product_consistent"],
        results["delivery_date_set"],
        results["poc_managed_set"],
    ])

    results["failed_items"] = [
        name for name, passed in [
            ("地址不完整（需含 street + city + state + ZIP）", results["address_complete"]),
            ("产品型号/颜色/尺码字段缺失", results["product_consistent"]),
            ("Promised Live Date 未填", results["delivery_date_set"]),
            ("POC 或 Manage by 未填", results["poc_managed_set"]),
        ] if not passed
    ]

    return results
```

---

### Step 3: 生成 Shipment Form 预填数据

当 `can_submit_shipment == True` 时：

```json
{
  "scene": "Act4_Shipment_Prefill",
  "record_id": "<record_id>",
  "influencer": "<Name of Entity>",
  "shipment_form": {
    "influencer": "<Name of Entity>",
    "product": "<Model Name>",
    "color": "<Color>",
    "size": "<Size>",
    "shipping_address": "<Shipping Address>",
    "promised_delivery_date": "<Promised Live Date>",
    "poc": "<POC>",
    "managed_by": "<Manage by>",
    "contract_file_link": "<Contract File Link>"
  },
  "four_checklist": {
    "address_complete": true,
    "product_consistent": true,
    "delivery_date_set": true,
    "poc_managed_set": true
  },
  "action": "ready_to_submit"
}
```

当 `can_submit_shipment == False` 时：

```json
{
  "scene": "Act4_Shipment_Prefill",
  "record_id": "<record_id>",
  "influencer": "<Name of Entity>",
  "can_submit_shipment": false,
  "failed_items": ["<失败项列表>"],
  "action": "do_not_submit",
  "recommendation": "补全上述项目后重新触发"
}
```

---

### Step 4: 输出 + 通知

**发给 SOPHIE**：

```
✅ 发货前四件自查全部通过
📦 产品：<Model Name>（<Color>, <Size>）
📍 地址：<Shipping Address>
📅 交付日期：<Promised Live Date>
👤 POC：<POC> / <Manage by>

请提交 Shipment Application 审批。
审批通过后 Gabriel 会安排发货。
```

**通知 Gabriel**（群聊）：

```
@Gabriel Reyes <Name of Entity> 的发货审批预计今天提交，
产品：<Model Name>，请提前备货。
```

---

## Q4 特殊处理（Daniel 2026-03-15 群聊）

若当前日期在 10-12 月之间，额外提醒：
- 提前 7 天 @ Gabriel
- 优先 FedEx / UPS 标准物流

---

## 后续动作（审批通过后）

回写 Base：
```json
{
  "Shipment Form Status": "Approved"
}
```

---

## 字段依赖

- app_token: `SvdqbQms3amuT5sgCQicLDzEnDf`
- table_id: `tblNOgYNV5KYszUl`
- 完整字段映射：`skills/pulsefit-base-reference/field_mapping.yaml`

## 规则来源

- 四件自查：Daniel 2026-03-15 群聊
- Q4 提前 7 天：SOP Section 4.4
