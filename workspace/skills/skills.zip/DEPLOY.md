# PulseFit Skills 部署说明

> 本目录包含 PulseFit Influencer Partnership 全流程自动化的所有 skill。
> 部署目标：让 Agent 能够响应飞书 Base 事件，自动执行 Act 4（发货审批）和 Act 5（付款审批）。

---

## 📦 技能包结构

```
skills/
├── pulsefit-base-reference/          # 全字段 ID 映射（所有 skill 共享）
│   └── SKILL.md
├── pulsefit-event-parsing/           # 通用：Base webhook → 统一事件格式
│   └── SKILL.md
├── pulsefit-scene-routing/           # 通用：Act 4 / Act 5 路由判断
│   └── SKILL.md
├── act4-shipment-verification/        # Act 4：发货审批（四件自查 + 预填）
│   └── SKILL.md
├── act5-payment-verification/        # Act 5：付款审批（五项校验 + 预填）
│   └── SKILL.md
├── pulsefit-base-read-write/         # 通用：Base 读写 + 回写操作
│   └── SKILL.md
├── pulsefit-sop-feedback/            # 通用：SOP 读取 + 反哺评论
│   └── SKILL.md
└── pulsefit-approval/                # 通用：审批创建 + 查询
    └── SKILL.md
```

---

## 🚀 快速部署

### Step 1：确认飞书 Base 配置

```yaml
app_token: SvdqbQms3amuT5sgCQicLDzEnDf
table_id:  tblNOgYNV5KYszUl
```

### Step 2：在 Base 中新增 Act 5 触发字段

**Plan B（已实现，无需手动操作）**：
已自动创建 `Payment Trigger` 文本字段（field_id: `fld8qUPbq8`）。
当 `Payment Trigger = "Invoice Received"` 时，自动触发 Act 5。

**Plan A（可选，更精确）**：在 Base UI 手动为 `Deliverable Status` 添加 `"Invoice Received"` 选项。

### Step 3：建议新增的字段（可选，提升自动化精度）

| 字段名 | 类型 | 用途 |
|--------|------|------|
| `W-9 Address` | 文本 | Act 5 地址一致性校验 |
| `Contract Address` | 文本 | 与 W-9 对比 |
| `Ready for Payment` | 复选框 | Act 5 辅助触发 |
| `Paid Usage Duration` | 文本/数字 | 记录 Paid Usage 时长 |

### Step 4：接入飞书 Base Webhook

在飞书开放平台配置 webhook，指向 Agent 的事件接收 endpoint：

```
触发事件：record_changed（记录字段变化）
订阅表：  tblNOgYNV5KYszUl
```

### Step 5：事件处理流程

```
飞书 Base 字段变化
    │
    ▼
event_parsing skill（解析 payload，提取 record_id + changed_fields）
    │
    ▼
scene_routing skill（判断是 act4 还是 act5）
    │
    ├── "act4" ──→ act4_shipment_verification skill
    │               ├── 四件自查
    │               ├── 生成预填数据
    │               └── 发通知给 SOPHIE + @ Gabriel
    │
    └── "act5" ──→ act5_payment_verification skill
                    ├── 五项 Deliverable Verification 校验
                    ├── 生成 Payment Form 预填数据
                    └── 发通知给 SOPHIE
```

---

## 🔑 触发条件速查

| Act | 触发字段 | 触发值 | 前提条件 |
|-----|---------|--------|---------|
| Act 4 | `Contract Application` | `Approved` | 合同审批已通过 |
| Act 5 | `Deliverable Status` | `Invoice Received` | 博主已发 invoice |

---

## 📋 Act 5 五项校验清单

（任何一项为 N → 不能提交付款申请）

1. ✅ `Total Posts Contracted == Total Posts Delivered`
2. ✅ `Bio Link Verified == true`
3. ✅ `Hashtags Verified == true`
4. ✅ `Paid Usage == true`
5. ✅ `Performance Updated == true`

**来源**：SOP Section 6.1 + Daniel 2026-04-09 群聊

---

## 📋 Act 4 四件自查清单

（任何一项未过 → 不能提交发货申请）

1. ✅ 地址完整（street + city + state + ZIP）
2. ✅ 产品型号、颜色、尺码与合同一致
3. ✅ `Promised Live Date` 已填
4. ✅ `POC` 和 `Manage by` 已填

**来源**：Daniel 2026-03-15 群聊；SOP Section 4.3

---

## 📁 规则来源文档（已存储在 workspace memory/）

- `memory/PulseFit_Influencer_Partnership_SOP.md`
- `memory/PulseFit_Mentor_Chat_History.md`
- `memory/PulseFit_Demo_Script.md`
- `memory/README.md`

---

## ⚠️ 已知限制

1. **审批创建 API**：`feishu_approval_*` 工具当前未在已启用列表中，建议先用 Base 字段模拟或 SOPHIE 手动提交审批
2. **W-9 / Contract Address 字段**：当前 Base 不存在，地址一致性校验无法自动化，建议补充
3. **Paid Usage Duration**：当前 Base 只有 `Paid Usage` 复选框，无时长记录，6 个月续期规则无法精确校验
4. **Base webhook**：需在飞书开放平台手动配置事件订阅

---

## 🧪 测试建议

**Act 4 测试**：
1. 找到一条 `Contract Application = Submitted` 的记录
2. 手动将其改为 `Approved`
3. Agent 应输出四件自查结果 + 发货表预填数据

**Act 5 测试**：
1. 找到一条 `Deliverable Status = Fully Delivered` 的记录
2. 手动将其改为 `Invoice Received`
3. Agent 应输出五项校验结果 + 付款表预填数据

---

最后更新：2026-05-05
